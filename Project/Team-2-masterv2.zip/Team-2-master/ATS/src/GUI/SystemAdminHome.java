package GUI;

import javax.swing.*;

public class SystemAdminHome {
    private JButton databaseButton;
    private JPanel panel1;
    private JButton createStaffAccountButton;
    private JButton stockButton;
    private JButton logOutButton;
    private JTextArea homeTextArea;
    private JButton addBlankButton;
}

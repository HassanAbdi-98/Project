package GUI;

import javax.swing.*;

public class AddBlank {
    private JTextArea blankIDTextArea;
    private JPanel panel1;
    private JTextArea blankTypeTextArea;
    private JTextArea departureLocationTextArea;
    private JTextArea arrivalLocationTextArea;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JTextField textField4;
    private JButton homeButton;
    private JButton logOutButton;
    private JButton addBlankButton;
    private JTextArea addBlankTextArea;
}

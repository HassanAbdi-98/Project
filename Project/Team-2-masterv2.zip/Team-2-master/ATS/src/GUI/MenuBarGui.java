package GUI;

import ATS.Start;

import javax.swing.*;

public abstract class MenuBarGui {

	private String staffName;
	private Start start;

	private JButton logOutButton;

	public void viewMainMenu() {
		// TODO - implement MenuBarGui.viewMainMenu
		throw new UnsupportedOperationException();
	}

	public void Logout() {
		// TODO - implement MenuBarGui.Logout
		throw new UnsupportedOperationException();
	}

	public abstract void common(MenuBarGui gui);

	public void common(Start start) {
		this.start = start;
	}

	public int getStaffID(){
		return start.getStaffID();
	}

}
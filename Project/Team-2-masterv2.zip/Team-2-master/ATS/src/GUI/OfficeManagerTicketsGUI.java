package GUI;

import GUI.*;

public class OfficeManagerTicketsGUI extends MenuBarGui {

	public void viewVoidBlank() {
		// TODO - implement OfficeManagerTicketsGUI.viewVoidBlank
		throw new UnsupportedOperationException();
	}

	public void viewAssignBlank() {
		// TODO - implement OfficeManagerTicketsGUI.viewAssignBlank
		throw new UnsupportedOperationException();
	}

	public void viewSelectTickets() {
		// TODO - implement OfficeManagerTicketsGUI.viewSelectTickets
		throw new UnsupportedOperationException();
	}

	public void viewCancelTicket() {
		// TODO - implement OfficeManagerTicketsGUI.viewCancelTicket
		throw new UnsupportedOperationException();
	}

	@Override
	public void common(MenuBarGui gui) {

	}
}
package GUI;

import javax.swing.*;

public class OfficeManagerHome {
    private JButton ticketsButton;
    private JPanel panel1;
    private JButton accessReportsButton;
    private JButton exchangeRateButton;
    private JButton createCustomerAccountButton;
    private JButton settingsButton;
    private JButton maintainCustomerAccountsButton;
    private JButton logOutButton;
    private JTextArea homeTextArea;
}

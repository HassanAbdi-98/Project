package GUI;

import javax.swing.*;

public class TicketSelection {
    private JButton logOutButton;
    private JButton homeButton;
    private JTextArea ticketSelectionTextArea;
    private JTextArea customerEmailTextArea;
    private JTextField textField1;
    private JButton createCustomerAccountButton;
    private JComboBox comboBox1;
    private JButton postponePaymentButton;
    private JButton takeCardPaymentButton;
    private JButton takeCashPaymentButton;
    private JButton addAnotherTicketToButton;
}

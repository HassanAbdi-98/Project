package GUI;

import javafx.util.Pair;

import javax.swing.*;
import java.util.Date;

public class GenerateReportGUI extends MenuBarGui {

    private String reportType;
    private Date startDate;
    private Date endDate;
    private Pair<Date,Date> ddPair;

    private JComboBox typeOfReport;
    private JTextField startDateText;
    private JTextField endDateText;
    private JButton generateReport;

    public Pair<Date,Date> generateFromToPairAmountPair(Date d1, Date d2) {
        ddPair = new Pair<>(d1,d2);
        return ddPair;
    }

    public void setReportType(String reportType) {
        this.reportType = reportType;
    }

    @Override
    public void common(MenuBarGui gui) {

    }
}
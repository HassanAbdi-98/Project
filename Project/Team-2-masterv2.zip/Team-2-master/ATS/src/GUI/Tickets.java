package GUI;

import javax.swing.*;

public class Tickets {
    private JButton voidBlankButton;
    private JPanel panel1;
    private JButton selectTicketsButton;
    private JButton assignReassignBlanksButton;
    private JButton cancelTicketsButton;
    private JButton homeButton;
    private JButton logOutButton;
    private JTextArea ticketsTextArea;
}

package GUI;

import javax.swing.*;

public class Login {
    private JTextField usernameTextField;
    private JPanel panel1;
    private JPasswordField passwordPasswordField;
    private JButton loginButton;
    private JTextArea airTicketSalesTextArea;
}

package GUI;

import javax.swing.*;

public class CreateStaffAccountGUI extends MenuBarGui {

	private String firstName;
	private String lastName;
	private String email;
	private int accessLevel;

	private JTextField firstNameTypeIn;
	private JTextField lastNameTypeIn;
	private JTextField emailTypeIn;
	private JComboBox accessLevelTypeIn;
	private JButton createStaffSave;

	/**
	 * 
	 * @param firstName
	 * @param lastName
	 * @param email
	 * @param accessLevel
	 */
	public void createStaffAccount(String firstName, String lastName, String email, int accessLevel) {
		// TODO - implement CreateStaffAccountGUI.createStaffAccount
		throw new UnsupportedOperationException();
	}

	public void retrieveAccessLevels() {
		// TODO - implement CreateStaffAccountGUI.retrieveAccessLevels
		throw new UnsupportedOperationException();
	}

	@Override
	public void common(MenuBarGui gui) {

	}
}
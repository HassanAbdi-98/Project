package GUI;

import javax.swing.*;

public class CancelTicket {
    private JPanel panel1;
    private JTextArea ticketIDTextArea;
    private JTextField textField1;
    private JButton confirmButton;
    private JButton homeButton;
    private JButton logOutButton;
    private JTextArea cancelTicketTextArea;
    private JTextArea refundAmountTextArea;
    private JTextField £000TextField;
}

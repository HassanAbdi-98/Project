package GUI;

import GUI.*;

public class OfficeManagerMainMenuGUI extends MenuBarGui {

	public void viewTickets() {
		// TODO - implement OfficeManagerMainMenuGUI.viewTickets
		throw new UnsupportedOperationException();
	}

	public void viewCreateCustomerAccount() {
		// TODO - implement OfficeManagerMainMenuGUI.viewCreateCustomerAccount
		throw new UnsupportedOperationException();
	}

	public void viewAccessReports() {
		// TODO - implement OfficeManagerMainMenuGUI.viewAccessReports
		throw new UnsupportedOperationException();
	}

	public void viewSettings() {
		// TODO - implement OfficeManagerMainMenuGUI.viewSettings
		throw new UnsupportedOperationException();
	}

	public void viewExchangeRate() {
		// TODO - implement OfficeManagerMainMenuGUI.viewExchangeRate
		throw new UnsupportedOperationException();
	}

	public void viewMaintainCustomerAccounts() {
		// TODO - implement OfficeManagerMainMenuGUI.viewMaintainCustomerAccounts
		throw new UnsupportedOperationException();
	}

	@Override
	public void common(MenuBarGui gui) {

	}
}
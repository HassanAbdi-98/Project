package GUI;

import GUI.*;

import javax.swing.*;

public class SysAdminMainMenuGUI extends MenuBarGui {

	private JButton viewDataBase;
	private JButton viewStock;
	private JButton createStaffAccount;

	public void viewDatabase() {
		// TODO - implement SysAdminMainMenuGUI.viewDatabase
		throw new UnsupportedOperationException();
	}

	public void viewStock() {
		// TODO - implement SysAdminMainMenuGUI.viewStock
		throw new UnsupportedOperationException();
	}

	public void viewCreateStaffAccount() {
		// TODO - implement SysAdminMainMenuGUI.viewCreateStaffAccount
		throw new UnsupportedOperationException();
	}

	@Override
	public void common(MenuBarGui gui) {

	}
}
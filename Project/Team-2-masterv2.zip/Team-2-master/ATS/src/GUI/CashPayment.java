package GUI;

import javax.swing.*;

public class CashPayment {
    private JTextArea amountDueTextArea;
    private JPanel panel1;
    private JTextArea paymentCurrencyTextArea;
    private JTextArea cashPaidTextArea;
    private JTextArea changeTextArea;
    private JTextField £000TextField;
    private JTextField textField2;
    private JComboBox comboBox1;
    private JTextField £000TextField1;
    private JTextArea cashPaymentTextArea;
}

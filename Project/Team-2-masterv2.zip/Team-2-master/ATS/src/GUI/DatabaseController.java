//package GUI;
//
//public class DatabaseController {
//
//	private String databaseURL;
//	private int port;
//	private String username;
//	private String password;
//	private int currentStaffID;
//
//	public void connect() {
//		// TODO - implement DatabaseController.connect
//		throw new UnsupportedOperationException();
//	}
//
//	public boolean connected() {
//		// TODO - implement DatabaseController.connected
//		throw new UnsupportedOperationException();
//	}
//
//	public DatabaseController() {
//		// TODO - implement DatabaseController.DatabaseController
//		throw new UnsupportedOperationException();
//	}
//
//	/**
//	 *
//	 * @param table
//	 * @param data
//	 */
//	public boolean pushToDatabase(String table, object data) {
//		// TODO - implement DatabaseController.pushToDatabase
//		throw new UnsupportedOperationException();
//	}
//
//	/**
//	 *
//	 * @param table
//	 * @param data
//	 */
//	public object retrieveFromDatabase(string table, object data) {
//		// TODO - implement DatabaseController.retrieveFromDatabase
//		throw new UnsupportedOperationException();
//	}
//
//	public string getDatabaseURL() {
//		return this.databaseURL;
//	}
//
//	/**
//	 *
//	 * @param databaseURL
//	 */
//	public void setDatabaseURL(string databaseURL) {
//		this.databaseURL = databaseURL;
//	}
//
//	public int getPort() {
//		return this.port;
//	}
//
//	/**
//	 *
//	 * @param port
//	 */
//	public void setPort(int port) {
//		this.port = port;
//	}
//
//	public string getUsername() {
//		return this.username;
//	}
//
//	/**
//	 *
//	 * @param username
//	 */
//	public void setUsername(string username) {
//		this.username = username;
//	}
//
//	public string getPassword() {
//		return this.password;
//	}
//
//	/**
//	 *
//	 * @param password
//	 */
//	public void setPassword(string password) {
//		this.password = password;
//	}
//
//}
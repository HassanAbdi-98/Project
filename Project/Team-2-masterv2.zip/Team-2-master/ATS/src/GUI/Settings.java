package GUI;

import javax.swing.*;

public class Settings {
    private JTextArea settingsTextArea;
    private JButton logOutButton;
    private JButton homeButton;
    private JTextArea commissionRateTextArea;
    private JTextArea newRateTextArea;
    private JTextField textField1;
    private JTextField textField2;
    private JButton setButton;
    private JTextArea flexibleTextArea;
    private JTextArea discountTextArea;
    private JTextArea newDiscountTextArea;
    private JTextField a8TextField;
    private JTextField textField3;
    private JButton setButton1;
    private JTextArea fixedTextArea;
    private JTextArea discountTextArea1;
    private JTextArea newDiscountTextArea1;
    private JTextField a10TextField;
    private JTextField textField5;
    private JButton setButton2;
}

package GUI;

import javax.swing.*;

public class ExchangeRate {
    private JButton homeButton;
    private JButton logOutButton;
    private JTextArea exchangeRateTextArea;
    private JTextArea exchangeRateTextArea1;
    private JTextArea newExchangeRateTextArea;
    private JTextField a128TextField;
    private JTextField textField1;
    private JButton setButton;
}

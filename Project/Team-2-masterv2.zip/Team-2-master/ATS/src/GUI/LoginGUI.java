package GUI;

import javax.swing.*;

public class LoginGUI extends MenuBarGui {

	private int staffID;
	private String Password;

	private JButton logIn;
	private JTextField loginID;
	private JPasswordField loginPassword;

	public void loginApproved() {
		// TODO - implement LoginGUI.loginApproved
		throw new UnsupportedOperationException();
	}

	public void loginDeny() {
		// TODO - implement LoginGUI.loginDeny
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param staffID
	 * @param password
	 */
	public void login(int staffID, String password) {
		// TODO - implement LoginGUI.login
		throw new UnsupportedOperationException();
	}


	@Override
	public void common(MenuBarGui gui) {

	}
}
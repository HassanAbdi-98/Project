package GUI;

import javax.swing.*;

public class Database {
    private JPanel panel1;
    private JButton homeButton;
    private JButton logOutButton;
    private JTextArea databaseTextArea;
}

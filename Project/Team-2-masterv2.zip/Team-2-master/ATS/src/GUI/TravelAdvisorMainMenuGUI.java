package GUI;

import GUI.*;

import javax.swing.*;

public class TravelAdvisorMainMenuGUI extends MenuBarGui {

	private JButton createCustomerAccount;
	private JButton cancelBlank;
	private JButton generateReport;
	private JButton stock;
	private JButton settings;

	public void viewCreateCustomerAccount() {
		// TODO - implement TravelAdvisorMainMenuGUI.viewCreateCustomerAccount
		throw new UnsupportedOperationException();
	}

	public void viewCancelTicket() {
		// TODO - implement TravelAdvisorMainMenuGUI.viewCancelTicket
		throw new UnsupportedOperationException();
	}

	public void viewAccessReports() {
		// TODO - implement TravelAdvisorMainMenuGUI.viewAccessReports
		throw new UnsupportedOperationException();
	}


	public void viewTickets() {
		// TODO - implement TravelAdvisorMainMenuGUI.viewTickets
		throw new UnsupportedOperationException();
	}

	public void viewSetting() {
		// TODO - implement TravelAdvisorMainMenuGUI.viewExchangeRate
		throw new UnsupportedOperationException();
	}

	@Override
	public void common(MenuBarGui gui) {

	}
}
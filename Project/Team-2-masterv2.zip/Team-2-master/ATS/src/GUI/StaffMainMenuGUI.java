package GUI;

public class StaffMainMenuGUI extends MenuBarGui {

    @Override
    public void common(MenuBarGui gui) {
    }
}



package GUI;

import javax.swing.*;

public class CardPayment {
    private JTextArea amountDueTextArea;
    private JTextArea cardNumberTextArea;
    private JTextArea CSVNumberTextArea;
    private JTextArea paymentCurrencyTextArea;
    private JTextArea expiryDateTextArea;
    private JTextField £000TextField;
    private JComboBox comboBox1;
    private JTextField textField2;
    private JTextField textField3;
    private JTextField textField1;
    private JTextArea cardPaymentTextArea;
    private JButton recordButton;
}

package GUI;

import javax.swing.*;

public class TravelAdvisorHome {
    private JButton cancelTicketButton;
    private JPanel panel1;
    private JButton accessReportsButton;
    private JButton exchangeRateButton;
    private JButton createCustomerAccountButton;
    private JButton selectTicketsButton;
    private JButton logOutButton;
    private JTextArea homeTextArea;
}

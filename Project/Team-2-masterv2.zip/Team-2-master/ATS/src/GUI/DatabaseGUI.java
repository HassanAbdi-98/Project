//package GUI;
//
//import java.util.LinkedList;
//
//public class DatabaseGUI extends MenuBarGui {
//
//	private String databaseURL;
//	private int port;
//	private String username;
//	private String password;
//
//	public LinkedList<String> getCredentials() {
//		// TODO - implement DatabaseGUI.getCredentials
//		throw new UnsupportedOperationException();
//	}
//
//}
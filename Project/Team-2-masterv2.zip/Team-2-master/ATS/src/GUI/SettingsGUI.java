package GUI;

import javax.swing.*;

public class SettingsGUI extends MenuBarGui {

	private float currentCommissionRate;
	private float newCommissionRate;
	private float currentFlexibleDisocount;
	private float newFlexibleDiscount;
	private float currentFixedDiscount;
	private float newFixedDiscount;
	private float currentExchangeRate;
	private float newExchangeRate;

	private JButton saveExchangeRate;
	private JButton saveCommissionRate;
	private JButton saveFlexibleDiscount;
	private JButton saveFixedDiscount;

	/**
	 * 
	 * @param newCommissionRate
	 */
	public void setCommissionRate(float newCommissionRate) {
		// TODO - implement SettingsGUI.setCommissionRate
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param newFlexibleDiscount
	 */
	public void setFlexibleDiscount(float newFlexibleDiscount) {
		// TODO - implement SettingsGUI.setFlexibleDiscount
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param newFixedDiscount
	 */
	public void setFixedDiscount(float newFixedDiscount) {
		// TODO - implement SettingsGUI.setFixedDiscount
		throw new UnsupportedOperationException();
	}

	public float getCurrentCommissionRate() {
		return this.currentCommissionRate;
	}

	/**
	 * 
	 * @param currentCommissionRate
	 */
	public void setCurrentCommissionRate(float currentCommissionRate) {
		this.currentCommissionRate = currentCommissionRate;
	}

	public float getCurrentFlexibleDisocount() {
		return this.currentFlexibleDisocount;
	}

	/**
	 * 
	 * @param currentFlexibleDisocount
	 */
	public void setCurrentFlexibleDisocount(float currentFlexibleDisocount) {
		this.currentFlexibleDisocount = currentFlexibleDisocount;
	}

	public float getCurrentFixedDiscount() {
		return this.currentFixedDiscount;
	}

	/**
	 * 
	 * @param currentFixedDiscount
	 */
	public void setCurrentFixedDiscount(float currentFixedDiscount) {
		this.currentFixedDiscount = currentFixedDiscount;
	}

	public float getCurrentExchangeRate() {
		return currentExchangeRate;
	}

	public void setCurrentExchangeRate(float currentExchangeRate) {
		this.currentExchangeRate = currentExchangeRate;
	}

	public float getNewExchangeRate() {
		return newExchangeRate;
	}

	public void setNewExchangeRate(float newExchangeRate) {
		this.newExchangeRate = newExchangeRate;
	}

	@Override
	public void common(MenuBarGui gui) {

	}
}
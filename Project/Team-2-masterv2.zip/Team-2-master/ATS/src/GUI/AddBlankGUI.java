package GUI;

import GUI.*;

import javax.swing.*;

public class AddBlankGUI extends MenuBarGui {

	private int blankID;
	private String blankType;
	private String departureLocation;
	private String arrivalLocation;

	private JTextField blankIDTypeIn;
	private JTextField blankTypeTypeIn;
	private JTextField departureLocationTypeIn;
	private JTextField arrivalLocationTypeIn;
	private JButton saveNewBlank;

	public void addBlank() {
		// TODO - implement AddBlankGUI.addBlank
		throw new UnsupportedOperationException();
	}

	@Override
	public void common(MenuBarGui gui) {

	}
}
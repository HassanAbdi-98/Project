package GUI;

import javax.swing.*;

public class GenerateReport {
    private JTextArea reportTypeTextArea;
    private JPanel panel1;
    private JTextArea deteRangeTextArea;
    private JTextField textField2;
    private JButton viewButton;
    private JButton deleteButton;
    private JButton homeButton;
    private JTextArea accessReportsTextArea;
    private JButton logOutButton;
    private JComboBox comboBox1;
}

package GUI;

import javax.swing.*;

public class CreateStaffAccount {
    private JTextArea firstNameTextArea;
    private JPanel panel1;
    private JTextArea lastNameTextArea;
    private JTextArea emailTextArea;
    private JTextArea accessLevelTextArea;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JButton createAccountButton;
    private JButton logOutButton;
    private JButton homeButton1;
    private JTextArea createStaffAccountTextArea;
    private JComboBox comboBox1;
}

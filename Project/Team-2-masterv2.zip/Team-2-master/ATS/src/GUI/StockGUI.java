package GUI;

import GUI.*;
import ATS.Tickets.Blank;

import javax.swing.*;
import java.util.Map;

public class StockGUI extends MenuBarGui {

	private Map<Blank, Integer> blanks;
	private int newAdvisorID;
	private int stockAssignmentID;
	private JButton addNewBlank;
	private JComboBox staffDropDown;

	/**
	 * 
	 * @param newAdvisorID
	 * @param stockAssignmentID
	 */
	public void updateBlankAssignment(int newAdvisorID, int stockAssignmentID) {
		// TODO - implement StockGUI.updateBlankAssignment
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param blankID
	 */
	public void makeBlankVoid(int blankID) {
		// TODO - implement StockGUI.makeBlankVoid
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param blankID
	 */
	public void deleteBlank(int blankID) {
		// TODO - implement StockGUI.deleteBlank
		throw new UnsupportedOperationException();
	}

	@Override
	public void common(MenuBarGui gui) {

	}
}
package GUI;

import javax.swing.*;

public class CreateCustomerAccount {
    private JButton homeButton;
    private JButton logOutButton;
    private JTextArea createCustomerAccountTextArea;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JTextArea firstNameTextArea;
    private JTextArea lastNameTextArea;
    private JTextArea emailTextArea;
    private JButton createAccountButton;
}

package ATS.Payment;

import GUI.MenuBarGui;

public class CardPayment extends GUI.Payment.Payment {

	private long cardNumber;
	private int expiryDate;
	private int csv;

	@Override
	public void common(MenuBarGui gui) {

	}
}
package GUI.Payment;

public class PaymentController {

	private boolean paymentSuccessful;

	/**
	 * 
	 * @param amountDue
	 * @param blanks
	 * @param cardNumber
	 * @param expiryDate
	 * @param csv
	 * @param cashGiven
	 * @param changeDue
	 */
	public void recordPayment(float amountDue, list<blanks> blanks, long cardNumber, int expiryDate, int csv, float cashGiven, float changeDue) {
		// TODO - implement PaymentController.recordPayment
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param paymentSuccessful
	 */
	public void setPaymentSuccessful(boolean paymentSuccessful) {
		this.paymentSuccessful = paymentSuccessful;
	}

}
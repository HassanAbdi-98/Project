package ATS.Payment;

import GUI.MenuBarGui;

public class CashPayment extends GUI.Payment.Payment {

	private float amountGiven;
	private float changeDue;

	/**
	 * 
	 * @param amountGiven
	 * @param changeDue
	 */
	public float calculateChange(float amountGiven, float changeDue) {
		// TODO - implement CashPayment.calculateChange
		throw new UnsupportedOperationException();
	}

	@Override
	public void common(MenuBarGui gui) {

	}
}
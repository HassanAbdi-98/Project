package ATS.Payment;

import GUI.*;
import ATS.Tickets.*;

import java.util.LinkedList;


public abstract class Payment extends MenuBarGui {

	private float amountDue;
	private LinkedList<Blank> blanks;

	public void paymentProcessed() {
		// TODO - implement Payment.paymentProcessed
		throw new UnsupportedOperationException();
	}

}
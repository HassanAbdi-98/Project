package ATS;

public class Customer {

	private String name;
	private String email;
	private String customerType = "regular";

	/**
	 * 
	 * @param name
	 * @param email
	 */
	public Customer(String name, String email) {
		name = this.name;
		email = this. email;
		// TODO - implement Customer.Customer
		throw new UnsupportedOperationException();
	}

	public Customer(String email) {
		email = this.email;
		// TODO - implement Customer.Customer
		throw new UnsupportedOperationException();
	}

	public String getName() {
		return this.name;
	}

	/**
	 * 
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return this.email;
	}

	public String getCustomerType() {
		return this.customerType;
	}

	/**
	 * 
	 * @param customerType
	 */
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

}
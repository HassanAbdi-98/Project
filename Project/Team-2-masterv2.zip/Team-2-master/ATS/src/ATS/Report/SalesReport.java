package ATS.Report;

import javafx.util.Pair;

import java.util.Date;

public class SalesReport extends GeneralReport {

	private int blankID;
	private int staffID;
	private float localCurrencyPrice;
	private float exchangeRate;
	private float usdPrice;
	private float creditCardUSD;
	private float creditCardLocalCurrenty;
	private float cashAmount;
	private float totalAmountPaid;
	private float totalNumberOfTickets;
	private float totalLocalCurrency;
	private float totalUSD;
	private float totalTotalAmountPaid;
	private float totalCash;
	private float totalCcUSD;
	private float totalCcLocalCurrency;
	private float totalNetAmountForBank;

	/**
	 * 
	 * @param period
	 * @param staffID
	 */
	public SalesReport(Pair<Date, Date> period, int staffID) {
		// TODO - implement SalesReport.SalesReport
		throw new UnsupportedOperationException();
	}

	public int getBlankID() {
		return this.blankID;
	}

	/**
	 * 
	 * @param blankID
	 */
	public void setBlankID(int blankID) {
		this.blankID = blankID;
	}

	public int getStaffID() {
		return this.staffID;
	}

	/**
	 * 
	 * @param staffID
	 */
	public void setStaffID(int staffID) {
		this.staffID = staffID;
	}

	public float getLocalCurrencyPrice() {
		return this.localCurrencyPrice;
	}

	/**
	 * 
	 * @param localCurrencyPrice
	 */
	public void setLocalCurrencyPrice(float localCurrencyPrice) {
		this.localCurrencyPrice = localCurrencyPrice;
	}

	public float getExchangeRate() {
		return this.exchangeRate;
	}

	/**
	 * 
	 * @param exchangeRate
	 */
	public void setExchangeRate(float exchangeRate) {
		this.exchangeRate = exchangeRate;
	}

	public float getUsdPrice() {
		return this.usdPrice;
	}

	/**
	 * 
	 * @param usdPrice
	 */
	public void setUsdPrice(float usdPrice) {
		this.usdPrice = usdPrice;
	}

	public float getCreditCardUSD() {
		return this.creditCardUSD;
	}

	/**
	 * 
	 * @param creditCardUSD
	 */
	public void setCreditCardUSD(float creditCardUSD) {
		this.creditCardUSD = creditCardUSD;
	}

	public float getCreditCardLocalCurrenty() {
		return this.creditCardLocalCurrenty;
	}

	/**
	 * 
	 * @param creditCardLocalCurrenty
	 */
	public void setCreditCardLocalCurrenty(float creditCardLocalCurrenty) {
		this.creditCardLocalCurrenty = creditCardLocalCurrenty;
	}

	public float getCashAmount() {
		return this.cashAmount;
	}

	/**
	 * 
	 * @param cashAmount
	 */
	public void setCashAmount(float cashAmount) {
		this.cashAmount = cashAmount;
	}

	public float getTotalAmountPaid() {
		return this.totalAmountPaid;
	}

	/**
	 * 
	 * @param totalAmountPaid
	 */
	public void setTotalAmountPaid(float totalAmountPaid) {
		this.totalAmountPaid = totalAmountPaid;
	}

	public float getTotalNumberOfTickets() {
		return this.totalNumberOfTickets;
	}

	/**
	 * 
	 * @param totalNumberOfTickets
	 */
	public void setTotalNumberOfTickets(float totalNumberOfTickets) {
		this.totalNumberOfTickets = totalNumberOfTickets;
	}

	public float getTotalLocalCurrency() {
		return this.totalLocalCurrency;
	}

	/**
	 * 
	 * @param totalLocalCurrency
	 */
	public void setTotalLocalCurrency(float totalLocalCurrency) {
		this.totalLocalCurrency = totalLocalCurrency;
	}

	public float getTotalUSD() {
		return this.totalUSD;
	}

	/**
	 * 
	 * @param totalUSD
	 */
	public void setTotalUSD(float totalUSD) {
		this.totalUSD = totalUSD;
	}

	public float getTotalTotalAmountPaid() {
		return this.totalTotalAmountPaid;
	}

	/**
	 * 
	 * @param totalTotalAmountPaid
	 */
	public void setTotalTotalAmountPaid(float totalTotalAmountPaid) {
		this.totalTotalAmountPaid = totalTotalAmountPaid;
	}

	public float getTotalCash() {
		return this.totalCash;
	}

	/**
	 * 
	 * @param totalCash
	 */
	public void setTotalCash(float totalCash) {
		this.totalCash = totalCash;
	}

	public float getTotalCcUSD() {
		return this.totalCcUSD;
	}

	/**
	 * 
	 * @param totalCcUSD
	 */
	public void setTotalCcUSD(float totalCcUSD) {
		this.totalCcUSD = totalCcUSD;
	}

	public float getTotalCcLocalCurrency() {
		return this.totalCcLocalCurrency;
	}

	/**
	 * 
	 * @param totalCcLocalCurrency
	 */
	public void setTotalCcLocalCurrency(float totalCcLocalCurrency) {
		this.totalCcLocalCurrency = totalCcLocalCurrency;
	}

	public float getTotalNetAmountForBank() {
		return this.totalNetAmountForBank;
	}

	/**
	 * 
	 * @param totalNetAmountForBank
	 */
	public void setTotalNetAmountForBank(float totalNetAmountForBank) {
		this.totalNetAmountForBank = totalNetAmountForBank;
	}

}
package ATS.Report;

import javafx.util.Pair;

import java.util.Date;

public abstract class GeneralReport {

	private String reportName;
	private Date generationTime;
	private String agent;
	private int number;
	private String salesOfficePlace;
	private Pair<Date, Date> period;
	private int batchNBR;
	private int portOfSale;
	private int operatorCode;
	private int reportNBR;

	protected GeneralReport() {
	}

	public void printReport() {
		// TODO - implement GeneralReport.printReport
		throw new UnsupportedOperationException();
	}

	public void calculateTotal() {
		// TODO - implement GeneralReport.calculateTotal
		throw new UnsupportedOperationException();
	}

	public void typeInperiod() {
		// TODO - implement GeneralReport.typeInperiod
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param period
	 */
	public GeneralReport(Pair<Date, Date> period) {
		// TODO - implement GeneralReport.GeneralReport
		throw new UnsupportedOperationException();
	}

	public String getReportName() {
		return this.reportName;
	}

	/**
	 * 
	 * @param reportName
	 */
	public void setReportName(String reportName) {
		this.reportName = reportName;
	}

	public Date getGenerationTime() {
		return this.generationTime;
	}

	/**
	 * 
	 * @param generationTime
	 */
	public void setGenerationTime(Date generationTime) {
		this.generationTime = generationTime;
	}

	public String getAgent() {
		return this.agent;
	}

	/**
	 * 
	 * @param agent
	 */
	public void setAgent(String agent) {
		this.agent = agent;
	}

	public int getNumber() {
		return this.number;
	}

	/**
	 * 
	 * @param number
	 */
	public void setNumber(int number) {
		this.number = number;
	}

	public String getSalesOfficePlace() {
		return this.salesOfficePlace;
	}

	/**
	 * 
	 * @param salesOfficePlace
	 */
	public void setSalesOfficePlace(String salesOfficePlace) {
		this.salesOfficePlace = salesOfficePlace;
	}

	public Pair<Date, Date> getPeriod() {
		return this.period;
	}

	/**
	 * 
	 * @param period
	 */
	public void setPeriod(Pair<Date, Date> period) {
		this.period = period;
	}

	public int getBatchNBR() {
		return this.batchNBR;
	}

	/**
	 * 
	 * @param batchNBR
	 */
	public void setBatchNBR(int batchNBR) {
		this.batchNBR = batchNBR;
	}

	public int getPortOfSale() {
		return this.portOfSale;
	}

	/**
	 * 
	 * @param portOfSale
	 */
	public void setPortOfSale(int portOfSale) {
		this.portOfSale = portOfSale;
	}

	public int getOperatorCode() {
		return this.operatorCode;
	}

	/**
	 * 
	 * @param operatorCode
	 */
	public void setOperatorCode(int operatorCode) {
		this.operatorCode = operatorCode;
	}

	public int getReportNBR() {
		return this.reportNBR;
	}

	/**
	 * 
	 * @param reportNBR
	 */
	public void setReportNBR(int reportNBR) {
		this.reportNBR = reportNBR;
	}

}
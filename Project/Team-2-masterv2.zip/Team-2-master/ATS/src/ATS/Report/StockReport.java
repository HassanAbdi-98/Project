package ATS.Report;

import javafx.util.Pair;

import java.util.Date;

public class StockReport extends GeneralReport {

	private int amount;
	private Sale[] preievedBlankAgentStockVector;
	private Sale[] preievedBlankSubAgentStockVector;
	private Sale[] assignedBlankStockVector;
	private Sale[] usedBlankStockVector;
	private Sale[] finalAgentStockVector;
	private Sale[] finalSubAgentStockVector;
	private Sale[] tempVector;
	private int totalPreievedAgentStock;
	private int totalPreievedSubAgnetStock;
	private int totalAssignedBlankStock;
	private int totalUsedBlankstock;
	private int totalFinalAgentStock;
	private int totalFinalSubagentStock;

	public StockReport(Pair<Date, Date> period, int staffID){

	}

	public pair generateFromToPairAmountPair() {
		// TODO - implement StockReport.generateFromToPairAmountPair
		throw new UnsupportedOperationException();
	}

	public int calculateAmount() {
		// TODO - implement StockReport.calculateAmount
		throw new UnsupportedOperationException();
	}

	public void genereateModelTable() {
		// TODO - implement StockReport.genereateModelTable
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param period
	 */
	public StockReport(pair<date, date> period) {
		// TODO - implement StockReport.StockReport
		throw new UnsupportedOperationException();
	}

	public int getAmount() {
		return this.amount;
	}

	/**
	 * 
	 * @param amount
	 */
	public void setAmount(int amount) {
		this.amount = amount;
	}

	public Sale[] getPreievedBlankAgentStockVector() {
		return this.preievedBlankAgentStockVector;
	}

	/**
	 * 
	 * @param preievedBlankAgentStockVector
	 */
	public void setPreievedBlankAgentStockVector(Sale[] preievedBlankAgentStockVector) {
		this.preievedBlankAgentStockVector = preievedBlankAgentStockVector;
	}

	public Sale[] getPreievedBlankSubAgentStockVector() {
		return this.preievedBlankSubAgentStockVector;
	}

	/**
	 * 
	 * @param preievedBlankSubAgentStockVector
	 */
	public void setPreievedBlankSubAgentStockVector(Sale[] preievedBlankSubAgentStockVector) {
		this.preievedBlankSubAgentStockVector = preievedBlankSubAgentStockVector;
	}

	public Sale[] getAssignedBlankStockVector() {
		return this.assignedBlankStockVector;
	}

	/**
	 * 
	 * @param assignedBlankStockVector
	 */
	public void setAssignedBlankStockVector(Sale[] assignedBlankStockVector) {
		this.assignedBlankStockVector = assignedBlankStockVector;
	}

	public Sale[] getUsedBlankStockVector() {
		return this.usedBlankStockVector;
	}

	/**
	 * 
	 * @param usedBlankStockVector
	 */
	public void setUsedBlankStockVector(Sale[] usedBlankStockVector) {
		this.usedBlankStockVector = usedBlankStockVector;
	}

	public Sale[] getFinalAgentStockVector() {
		return this.finalAgentStockVector;
	}

	/**
	 * 
	 * @param finalAgentStockVector
	 */
	public void setFinalAgentStockVector(Sale[] finalAgentStockVector) {
		this.finalAgentStockVector = finalAgentStockVector;
	}

	public Sale[] getFinalSubAgentStockVector() {
		return this.finalSubAgentStockVector;
	}

	/**
	 * 
	 * @param finalSubAgentStockVector
	 */
	public void setFinalSubAgentStockVector(Sale[] finalSubAgentStockVector) {
		this.finalSubAgentStockVector = finalSubAgentStockVector;
	}

	public Sale[] getTempVector() {
		return this.tempVector;
	}

	/**
	 * 
	 * @param tempVector
	 */
	public void setTempVector(Sale[] tempVector) {
		this.tempVector = tempVector;
	}

	public int getTotalPreievedAgentStock() {
		return this.totalPreievedAgentStock;
	}

	/**
	 * 
	 * @param totalPreievedAgentStock
	 */
	public void setTotalPreievedAgentStock(int totalPreievedAgentStock) {
		this.totalPreievedAgentStock = totalPreievedAgentStock;
	}

	public int getTotalPreievedSubAgnetStock() {
		return this.totalPreievedSubAgnetStock;
	}

	/**
	 * 
	 * @param totalPreievedSubAgnetStock
	 */
	public void setTotalPreievedSubAgnetStock(int totalPreievedSubAgnetStock) {
		this.totalPreievedSubAgnetStock = totalPreievedSubAgnetStock;
	}

	public int getTotalAssignedBlankStock() {
		return this.totalAssignedBlankStock;
	}

	/**
	 * 
	 * @param totalAssignedBlankStock
	 */
	public void setTotalAssignedBlankStock(int totalAssignedBlankStock) {
		this.totalAssignedBlankStock = totalAssignedBlankStock;
	}

	public int getTotalUsedBlankstock() {
		return this.totalUsedBlankstock;
	}

	/**
	 * 
	 * @param totalUsedBlankstock
	 */
	public void setTotalUsedBlankstock(int totalUsedBlankstock) {
		this.totalUsedBlankstock = totalUsedBlankstock;
	}

	public int getTotalFinalAgentStock() {
		return this.totalFinalAgentStock;
	}

	/**
	 * 
	 * @param totalFinalAgentStock
	 */
	public void setTotalFinalAgentStock(int totalFinalAgentStock) {
		this.totalFinalAgentStock = totalFinalAgentStock;
	}

	public int getTotalFinalSubagentStock() {
		return this.totalFinalSubagentStock;
	}

	/**
	 * 
	 * @param totalFinalSubagentStock
	 */
	public void setTotalFinalSubagentStock(int totalFinalSubagentStock) {
		this.totalFinalSubagentStock = totalFinalSubagentStock;
	}

}
package ATS;

import GUI.LoginGUI;
import GUI.MenuBarGui;

import java.awt.*;
import java.util.*;
import javax.swing.JFrame;

    public class Start{
        private GUI.MenuBarGui currentGUI;
        private JFrame frame;
        private int staffID;


        public Start(){

            currentGUI = new LoginGUI();
            currentGUI.common(this);
            frame = new JFrame("ATS");

        }

        public void change(String x){
            switch(x){

                // go back to login page
                case "logout":
                    break;

                case "report":
                    break;

                case "addBlank":
                    break;

                case "cancelBlank" :
                    break;

                case "createCustomerAccount":
                    break;

                case "createStaffAccount":
                    break;

                case "setting":
                    break;

                case "stock":
                    break;

                case"staffMainPage":
                    break;

                case"saleBlank":
                    break;
                case"back":
                    break;
            }

        }
        public int getStaffID(){
            return staffID;
        }
        public static void main(String[] args) {
            new Start();
        }
}















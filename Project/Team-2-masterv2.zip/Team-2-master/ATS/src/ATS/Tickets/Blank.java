package ATS.Tickets;

import java.util.LinkedList;

public class Blank {

	private int blankID;
	private LinkedList<Coupon> couponList;
	private String departureLocation;
	private String arrivalLocation;
	private String status = "waiting";
	private String type;

	/**
	 * 
	 * @param blankID
	 * @param departureLocation
	 * @param arrivalLocation
	 * @param type
	 */
	public Blank(int blankID, String departureLocation, String arrivalLocation, int type) {
		// TODO - implement Blank.Blank
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param blankID
	 */
	public Blank(int blankID) {
		// TODO - implement Blank.Blank
		throw new UnsupportedOperationException();
	}

	public int getBlankID() {
		return this.blankID;
	}

	/**
	 * 
	 * @param blankID
	 */
	public void setBlankID(int blankID) {
		this.blankID = blankID;
	}

	public LinkedList<Coupon> getCouponList() {
		return this.couponList;
	}

	/**
	 * 
	 * @param couponList
	 */
	public void setCouponList(LinkedList<Coupon> couponList) {
		this.couponList = couponList;
	}

	public String getDepartureLocation() {
		return this.departureLocation;
	}

	/**
	 * 
	 * @param departureLocation
	 */
	public void setDepartureLocation(String departureLocation) {
		this.departureLocation = departureLocation;
	}

	public String getArrivalLocation() {
		return this.arrivalLocation;
	}

	/**
	 * 
	 * @param arrivalLocation
	 */
	public void setArrivalLocation(String arrivalLocation) {
		this.arrivalLocation = arrivalLocation;
	}

	public String getStatus() {
		return this.status;
	}

	/**
	 * 
	 * @param status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	public String getType() {
		return this.type;
	}

	/**
	 * 
	 * @param type
	 */
	public void setType(String type) {
		this.type = type;
	}

}
package ATS.Tickets;

import javafx.util.Pair;

import java.util.Date;

public class IntTwoCouponBlank {

	private int intAutoTwoBlankType = 420;

	/**
	 * 
	 * @param blankID
	 * @param customerEmail
	 * @param paymentMethod
	 */
	public IntTwoCouponBlank(Pair<Date, Date> period, int staffID, int blankID, String customerEmail, boolean paymentMethod) {
		// TODO - implement IntTwoCouponBlank.IntTwoCouponBlank
		throw new UnsupportedOperationException();
	}

}
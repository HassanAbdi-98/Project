package ATS.Tickets;

import javafx.util.Pair;

import java.util.Date;

public class International {

	private float tax;
	private float creditCardLc;
	private float creditCardFullCcNumber;
	private float nonAssessAmount;
	private float toalLzTax;
	private float totalOtherTax;
	private float totalNonAssessAmount;

	/**
	 * 
	 * @param period
	 * @param staffID
	 */
	public International(Pair<Date, Date> period, int staffID) {
		// TODO - implement International.International
		throw new UnsupportedOperationException();
	}

	public float getTax() {
		return this.tax;
	}

	/**
	 * 
	 * @param tax
	 */
	public void setTax(float tax) {
		this.tax = tax;
	}

	public float getCreditCardLc() {
		return this.creditCardLc;
	}

	/**
	 * 
	 * @param creditCardLc
	 */
	public void setCreditCardLc(float creditCardLc) {
		this.creditCardLc = creditCardLc;
	}

	public float getCreditCardFullCcNumber() {
		return this.creditCardFullCcNumber;
	}

	/**
	 * 
	 * @param creditCardFullCcNumber
	 */
	public void setCreditCardFullCcNumber(float creditCardFullCcNumber) {
		this.creditCardFullCcNumber = creditCardFullCcNumber;
	}

	public float getNonAssessAmount() {
		return this.nonAssessAmount;
	}

	/**
	 * 
	 * @param nonAssessAmount
	 */
	public void setNonAssessAmount(float nonAssessAmount) {
		this.nonAssessAmount = nonAssessAmount;
	}

	public float getToalLzTax() {
		return this.toalLzTax;
	}

	/**
	 * 
	 * @param toalLzTax
	 */
	public void setToalLzTax(float toalLzTax) {
		this.toalLzTax = toalLzTax;
	}

	public float getTotalOtherTax() {
		return this.totalOtherTax;
	}

	/**
	 * 
	 * @param totalOtherTax
	 */
	public void setTotalOtherTax(float totalOtherTax) {
		this.totalOtherTax = totalOtherTax;
	}

	public float getTotalNonAssessAmount() {
		return this.totalNonAssessAmount;
	}

	/**
	 * 
	 * @param totalNonAssessAmount
	 */
	public void setTotalNonAssessAmount(float totalNonAssessAmount) {
		this.totalNonAssessAmount = totalNonAssessAmount;
	}

}
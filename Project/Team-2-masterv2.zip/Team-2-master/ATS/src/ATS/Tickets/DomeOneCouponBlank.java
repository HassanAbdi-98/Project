package ATS.Tickets;

public class DomeOneCouponBlank {

	private int domeAutoOneBlankType = 101;

	/**
	 * 
	 * @param blankID
	 * @param customerEmail
	 * @param paymentMethod
	 */
	public DomeOneCouponBlank(int blankID, String customerEmail, boolean paymentMethod) {
		// TODO - implement DomeOneCouponBlank.DomeOneCouponBlank
		throw new UnsupportedOperationException();
	}

}
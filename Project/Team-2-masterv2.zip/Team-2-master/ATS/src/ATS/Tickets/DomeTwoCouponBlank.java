package ATS.Tickets;

public class DomeTwoCouponBlank {

	private int domeAutoTwoBlankType = 201;

	/**
	 * 
	 * @param blankID
	 * @param customerEmail
	 * @param paymentMethod
	 */
	public DomeTwoCouponBlank(int blankID, String customerEmail, boolean paymentMethod) {
		// TODO - implement DomeTwoCouponBlank.DomeTwoCouponBlank
		throw new UnsupportedOperationException();
	}

}
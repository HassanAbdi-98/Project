package ATS.Tickets;

public class Coupon {

	private int couponID;
	private String departureLocation;
	private String arrivalLocation;
	private String status;
	private String type;

	/**
	 * 
	 * @param couponID
	 * @param departureLocation
	 * @param arrivalLocation
	 */
	public Coupon(int couponID, String departureLocation, String arrivalLocation) {
		// TODO - implement Coupon.Coupon
		// Used when creating a coupon
		throw new UnsupportedOperationException();
	}


	/**
	 * 
	 * @param couponID
	 */
	public Coupon(int couponID) {
		// TODO - implement Coupon.Coupon
		//Used when search a coupon
		throw new UnsupportedOperationException();
	}

	public int getCouponID() {
		return this.couponID;
	}

	/**
	 * 
	 * @param couponID
	 */
	public void setCouponID(int couponID) {
		this.couponID = couponID;
	}

	public String getDepartureLocation() {
		return this.departureLocation;
	}

	/**
	 * 
	 * @param departureLocation
	 */
	public void setDepartureLocation(String departureLocation) {
		this.departureLocation = departureLocation;
	}

	public String getArrivalLocation() {
		return this.arrivalLocation;
	}

	/**
	 * 
	 * @param arrivalLocation
	 */
	public void setArrivalLocation(String arrivalLocation) {
		this.arrivalLocation = arrivalLocation;
	}

	public String getStatus() {
		return this.status;
	}

	/**
	 * 
	 * @param status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	public String getType() {
		return this.type;
	}

	/**
	 * 
	 * @param type
	 */
	public void setType(String type) {
		this.type = type;
	}

}
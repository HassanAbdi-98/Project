package ATS.Tickets;

import javafx.util.Pair;

import java.util.Date;

public class Domestic {

	private float chequePayment;
	private float invoicePayment;
	private float totalTax;
	private float commissionRate;
	private float commissionAmount;
	private String notes1;
	private String otherDetails;
	private String notes2;

	/**
	 * 
	 * @param period
	 * @param staffID
	 */
	public Domestic(Pair<Date, Date> period, int staffID) {
		// TODO - implement Domestic.Domestic
		throw new UnsupportedOperationException();
	}

	public float getChequePayment() {
		return this.chequePayment;
	}

	/**
	 * 
	 * @param chequePayment
	 */
	public void setChequePayment(float chequePayment) {
		this.chequePayment = chequePayment;
	}

	public float getInvoicePayment() {
		return this.invoicePayment;
	}

	/**
	 * 
	 * @param invoicePayment
	 */
	public void setInvoicePayment(float invoicePayment) {
		this.invoicePayment = invoicePayment;
	}

	public float getTotalTax() {
		return this.totalTax;
	}

	/**
	 * 
	 * @param totalTax
	 */
	public void setTotalTax(float totalTax) {
		this.totalTax = totalTax;
	}

	public float getCommissionRate() {
		return this.commissionRate;
	}

	/**
	 * 
	 * @param commissionRate
	 */
	public void setCommissionRate(float commissionRate) {
		this.commissionRate = commissionRate;
	}

	public float getCommissionAmount() {
		return this.commissionAmount;
	}

	/**
	 * 
	 * @param commissionAmount
	 */
	public void setCommissionAmount(float commissionAmount) {
		this.commissionAmount = commissionAmount;
	}

	public String getNotes1() {
		return this.notes1;
	}

	/**
	 * 
	 * @param notes1
	 */
	public void setNotes1(String notes1) {
		this.notes1 = notes1;
	}

	public String getOtherDetails() {
		return this.otherDetails;
	}

	/**
	 * 
	 * @param otherDetails
	 */
	public void setOtherDetails(String otherDetails) {
		this.otherDetails = otherDetails;
	}

	public String getNotes2() {
		return this.notes2;
	}

	/**
	 * 
	 * @param notes2
	 */
	public void setNotes2(String notes2) {
		this.notes2 = notes2;
	}

}
package ATS.Tickets;

import javafx.util.Pair;

import java.util.Date;

public class IntManualBlank {

	private int intManualBlankType = 440;

	/**
	 * 
	 * @param blankID
	 * @param customerEmail
	 * @param paymentMethod
	 */
	public IntManualBlank(Pair<Date, Date> period, int staffID, int blankID, String customerEmail, boolean paymentMethod) {
		// TODO - implement IntManualBlank.IntManualBlank
		throw new UnsupportedOperationException();
	}

}
package ATS.Tickets;

import javafx.util.Pair;

import java.util.Date;

public class IntFourCouponBlank {

	private int intAutoFourBlankType = 444;

	/**
	 * 
	 * @param blankID
	 * @param customerEmail
	 * @param paymentMethod
	 */
	public IntFourCouponBlank(Pair<Date, Date> period, int staffID, int blankID, String customerEmail, boolean paymentMethod) {
		// TODO - implement IntFourCouponBlank.IntFourCouponBlank
		throw new UnsupportedOperationException();
	}

}
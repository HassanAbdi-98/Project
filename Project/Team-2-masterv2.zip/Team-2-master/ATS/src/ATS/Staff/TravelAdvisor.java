package ATS.Staff;

public class TravelAdvisor extends GeneralStaff {

	public TravelAdvisor(int staffID, String name, String role) {
		super(staffID, name, role);
	}

	public TravelAdvisor(int staffID) {
		super(staffID);
	}

	public void generateIndividualStockReport() {
		// TODO - implement TravelAdvisor.generateIndividualStockReport
		throw new UnsupportedOperationException();
	}

	public void generateIndividualSalesReport() {
		// TODO - implement TravelAdvisor.generateIndividualSalesReport
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param email
	 * @param password
	 * @param name
	 */
	public void createCustomerAccount(String email, String password, String name) {
		// TODO - implement TravelAdvisor.createCustomerAccount
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param customerEmail
	 * @param advisorID
	 * @param departureLocation
	 * @param arrivalLocation
	 */
	public void sellBlank(String customerEmail, int advisorID, String departureLocation, String arrivalLocation) {
		// TODO - implement TravelAdvisor.sellBlank
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param blankID
	 */
	public void refundBlank(int blankID) {
		// TODO - implement TravelAdvisor.refundBlank
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param exchangeRate
	 */
	public void changeExchange(float exchangeRate) {
		// TODO - implement TravelAdvisor.changeExchange
		throw new UnsupportedOperationException();
	}

}
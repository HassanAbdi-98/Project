package ATS.Staff;

public abstract class GeneralStaff {

	private int staffID;
	private String name;
	private String role;

	/**
	 * 
	 * @param staffID
	 * @param name
	 * @param role
	 */
	public GeneralStaff(int staffID, String name, String role) {

	}

	public int getStaffID() {
		return this.staffID;
	}

	/**
	 * 
	 * @param staffID
	 */
	public void setStaffID(int staffID) {
		this.staffID = staffID;
	}

	public String getName() {
		return this.name;
	}

	/**
	 * 
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	public String getRole() {
		return this.role;
	}

	/**
	 * 
	 * @param role
	 */
	public void setRole(String role) {
		this.role = role;
	}

	/**
	 * 
	 * @param staffID
	 */
	public GeneralStaff(int staffID) {
		// TODO - implement GeneralStaff.GeneralStaff
		throw new UnsupportedOperationException();
	}

}
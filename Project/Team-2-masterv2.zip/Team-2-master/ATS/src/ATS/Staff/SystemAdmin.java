package ATS.Staff;

public class SystemAdmin extends GeneralStaff {

	public SystemAdmin(int staffID) {
		super(staffID);
	}

	public void restoreDatabase() {
		// TODO - implement SystemAdmin.restoreDatabase
		throw new UnsupportedOperationException();
	}

	public void backupDatabase() {
		// TODO - implement SystemAdmin.backupDatabase
		throw new UnsupportedOperationException();
	}

	public void accessStockDatabase() {
		// TODO - implement SystemAdmin.accessStockDatabase
		throw new UnsupportedOperationException();
	}

	public void changeEncryptionSalt() {
		// TODO - implement SystemAdmin.changeEncryptionSalt
		throw new UnsupportedOperationException();
	}

}
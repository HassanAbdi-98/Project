package ATS.Staff;

public class OfficeManager extends GeneralStaff{

	public OfficeManager(int staffID, String name, String role) {
		super(staffID, name, role);
	}

	public OfficeManager(int staffID) {
		super(staffID);
	}

	public void changeCommissionRate() {
		// TODO - implement OfficeManager.changeCommissionRate
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param fixedDiscount
	 */
	public void giveFixedDiscount(float fixedDiscount) {
		// TODO - implement OfficeManager.giveFixedDiscount
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param flexibleDiscount
	 */
	public void giveFlexibleDiscount(int flexibleDiscount) {
		// TODO - implement OfficeManager.giveFlexibleDiscount
		throw new UnsupportedOperationException();
	}

	public void assignBlank() {
		// TODO - implement OfficeManager.assignBlank
		throw new UnsupportedOperationException();
	}

	public void reAssignBlank() {
		// TODO - implement OfficeManager.reAssignBlank
		throw new UnsupportedOperationException();
	}

	public void generateGlobalSalesReport() {
		// TODO - implement OfficeManager.generateGlobalSalesReport
		throw new UnsupportedOperationException();
	}

	public void generateGlobalStockReport() {
		// TODO - implement OfficeManager.generateGlobalStockReport
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param commissionRate
	 */
	public void changeCommission(float commissionRate) {
		// TODO - implement OfficeManager.changeCommission
		throw new UnsupportedOperationException();
	}

}
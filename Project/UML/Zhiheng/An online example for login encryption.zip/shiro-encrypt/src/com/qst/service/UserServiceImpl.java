package com.qst.service;

import com.qst.dao.UserDao;
import com.qst.dao.UserDaoImpl;
import com.qst.po.Users;

public class UserServiceImpl implements UserService {
	UserDao userdao=new UserDaoImpl();
	public Users login(String uname) {
		
		Users user=userdao.login(uname);
		return user;
	}
	public void add(Users user) {
		
		userdao.add(user);
	
		
	}


}

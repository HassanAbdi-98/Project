package com.qst.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.qst.po.Users;
import com.qst.util.DBUtil;



public class UserDaoImpl implements UserDao {
	Users bean= null;
	
	public Users login(String uname) {
		
		Users user=new Users();
		 
		  
	        try (Connection c = DBUtil.getConnection(); Statement s = c.createStatement();) {
	  
	        	String sql="select * from users where uname ='"+uname+"'";
	        	//String sql="from ActiveCert ac where ac.issuerName='"+issueName+"'";
	  
	            ResultSet rs = s.executeQuery(sql);
	  
	            if (rs.next()) {
	 
	                String name = rs.getString("uname");
	                String salt = rs.getString("salt"); 
	                String upass=rs.getString("password");
	                user.setUname(uname);
	                user.setSalt(salt);
	                user.setUpass(upass);
	                bean=user;
	                
	                
	              
	            }
	         
	  
	        } catch (SQLException e) {
	  
	            e.printStackTrace();
	        }
	        return bean;
		
		
	}

	@Override
	public void add(Users user) {
		
		   String sql = "insert into users values(null,?,?,?)";
	        try (Connection c = DBUtil.getConnection(); PreparedStatement ps = c.prepareStatement(sql);) {
	  
	          //  ps.setInt(1, user.getId());
	            ps.setString(1, user.getUname());
	            ps.setString(2, user.getUpass());
	            ps.setString(3, user.getSalt());

	            ps.execute();
	  
	            ResultSet rs = ps.getGeneratedKeys();
	            if (rs.next()) {
	                int id = rs.getInt(1);
	                user.setId(id);
	            }
	        } catch (SQLException e) {
	  
	            e.printStackTrace();
	        }
		
		
	}

}

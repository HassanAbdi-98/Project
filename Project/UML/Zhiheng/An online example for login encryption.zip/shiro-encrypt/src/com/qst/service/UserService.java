package com.qst.service;

import com.qst.po.Users;

public interface UserService {
	
	public Users login(String uname);
	
	public void add(Users user);
	
	
}

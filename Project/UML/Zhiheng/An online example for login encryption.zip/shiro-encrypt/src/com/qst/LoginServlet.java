package com.qst;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.shiro.crypto.hash.Sha256Hash;

import com.qst.po.Users;
import com.qst.service.UserService;
import com.qst.service.UserServiceImpl;



/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public LoginServlet() {
        super();
  
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String uname = request.getParameter("uname");
		String upass = request.getParameter("upass");
		
		UserService userService=new UserServiceImpl();
		
		//�������������û�����ȡ������salt
		Users user=userService.login(uname);
		
		if(user==null||!user.getUpass().equals(new Sha256Hash(upass,user.getSalt()).toString())) {
		
			
			response.sendRedirect(request.getContextPath()+"/failure.jsp");
			
		}else {
			HttpSession session = request.getSession();
			session.setAttribute("user", user);
			request.getRequestDispatcher("/success.jsp").forward(request, response);
		}
		
	
	
	}

}

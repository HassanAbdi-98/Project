package com.qst.dao;

import com.qst.po.Users;

public interface UserDao {
	
	public Users login(String uname);
	
	public void add(Users user);

}

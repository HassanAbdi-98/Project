package com.qst;

import java.io.IOException;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.shiro.crypto.hash.Sha256Hash;

import com.qst.po.Users;
import com.qst.service.UserService;
import com.qst.service.UserServiceImpl;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		UserService userService=new UserServiceImpl();
		
		request.setCharacterEncoding("UTF-8");
		
		String uname=request.getParameter("uname");
		
		String upass=request.getParameter("upass");
		//Ϊע���û�����
		String  salt=UUID.randomUUID().toString();
		
		String pass=new Sha256Hash(upass,salt).toString();
		
		Users user=new Users(uname,pass,salt);
			
		userService.add(user);
		
		request.getRequestDispatcher("index.jsp").forward(request, response);
		
		
		
	}

}
